-- Sample SQL Queries
SELECT * FROM cleaned_data LIMIT 10;
SELECT COUNT(*) FROM cleaned_data;
