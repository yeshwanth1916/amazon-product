import pandas as pd
import sqlite3
import matplotlib.pyplot as plt
import zipfile
import os

# Load CSV
csv_path = "raw_data_cleaning.csv"
df = pd.read_csv(csv_path)

# Create SQLite DB
db_path = "cleaned_dataset.db"
conn = sqlite3.connect(db_path)

table_name = "cleaned_data"
df.to_sql(table_name, conn, if_exists="replace", index=False)
conn.close()

print("Data successfully inserted into SQL database!")

# -------------------------------
# Visualization Section
# -------------------------------

# create a visualization showing which ProductId is sold most frequently
if "ProductId" in df.columns:
    freq = df["ProductId"].value_counts()

    plt.figure()
    # only show top 10 products to keep the chart readable
    freq.head(10).plot(kind="bar")
    plt.title("Top 10 Most Frequently Sold Products")
    plt.xlabel("ProductId")
    plt.ylabel("Number of Sales")

    plot_path = "visualization.png"
    plt.savefig(plot_path)  
    plt.show()                
    plt.close()

    print("Visualization generated successfully!")
else:
    plot_path = None
    print("ProductId column not found for visualization.")

# -------------------------------
# Create SQL File
# -------------------------------

sql_script_path = "sample_queries.sql"
with open(sql_script_path, "w") as f:
    f.write("-- Sample SQL Queries\n")
    f.write(f"SELECT * FROM {table_name} LIMIT 10;\n")
    f.write(f"SELECT COUNT(*) FROM {table_name};\n")

print("SQL query file created!")

# -------------------------------
# Create ZIP File
# -------------------------------

zip_path = "SQL_Visualization_Project.zip"
with zipfile.ZipFile(zip_path, 'w') as zipf:
    zipf.write(csv_path)
    zipf.write(db_path)
    if plot_path:
        zipf.write(plot_path)
    zipf.write(sql_script_path)

print("Project ZIP Created Successfully!")